﻿using iProcedure.Crop;
using iProcedure.ViewModel;
using SkiaSharp;
using SkiaSharp.Views.Maui;
using SkiaSharp.Views.Maui.Controls;
using System.Windows.Input;

namespace iProcedure.View;

public partial class EditImagePage : ContentPage
{
    public EditImagePage()
    {
        InitializeComponent();
        NavigationPage.SetHasNavigationBar(this, false);
        
        var vm = (EditImageViewModel)BindingContext;

        vm.skiaView = skiaView;
        vm.Init();
        vm.CallTogglePopupLayoutCommandEvent += OnTogglePopupLayoutCommand;
    }

    internal void OnTogglePopupLayoutCommand()
    {
        if (!PopupLayout.IsVisible)
        {
            PopupLayout.IsVisible = true;
            PopupLayout.MaximumHeightRequest = Height > 0 ? Height : 10000;
            var bounds = PopupLayout.Measure(Width, Height);

            PopupLayout.Opacity = 0;
            PopupLayout.MaximumHeightRequest = 0;

            var animation = new Animation();
            animation.Add(0, 1, new Animation(v => PopupLayout.Opacity = v, 0, 1));
            animation.Add(0, 1, new Animation(v => PopupLayout.MaximumHeightRequest = v, 0, bounds.Request.Height));

            animation.Commit(PopupLayout, nameof(PopupLayout), length: 500, easing: Easing.CubicOut);
        }
        else
        {
            var animation = new Animation();
            animation.Add(0, 1, new Animation(v => PopupLayout.Opacity = v, 1, 0));
            animation.Add(0, 1, new Animation(v => PopupLayout.MaximumHeightRequest = v, PopupLayout.Height, 0));

            animation.Commit(PopupLayout, nameof(PopupLayout), length: 500, easing: Easing.CubicOut,
                finished: (v, f) => PopupLayout.IsVisible = false);
        }
    }

    private void OnTouch(object sender, SKTouchEventArgs e)
    {
        var vm = (EditImageViewModel)BindingContext;
        vm.SKCanvasViewWidth = this.Width;
        vm.SKCanvasViewHeight = this.Height - 140;
        vm.OnTouch(sender, e);
    }

    private void OnPaintSurface(object sender, SKPaintSurfaceEventArgs e)
    {
        var vm = (EditImageViewModel)BindingContext;
        vm.OnPaintSurface(sender, e);
    }

    private void ContentPage_Loaded(object sender, EventArgs e)
    {
        //OnTogglePopupLayoutCommand();
        //CropLayout.IsVisible = true;
        //ResizeLayout.IsVisible = false;
    }

    private void OnCrop(object sender, EventArgs e)
    {
        CropLayout.IsVisible = true;
        ResizeLayout.IsVisible = false;
    }

    private void OnResize(object sender, EventArgs e)
    {
        CropLayout.IsVisible = false;
        ResizeLayout.IsVisible = true;
    }
}